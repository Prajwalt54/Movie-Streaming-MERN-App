const mongoose = require('mongoose');

const MovieSchema = new mongoose.Schema({
    title: { type: String, required: true },
    image: { type: String, required: true },
    description: String,
    category: String, 
    genre: String,    
    videoUrl: String
});

module.exports = mongoose.model('Movie', MovieSchema);