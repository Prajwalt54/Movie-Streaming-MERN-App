const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
require('dotenv').config(); 

const apiRoutes = require('./routes/api');
const app = express();

app.use(cors());
app.use(express.json());

mongoose.connect(process.env.MONGO_URI,{dbName:'movieDB'})
    .then(() => console.log(" Connected to MongoDB"))
    .catch(err => console.error(" MongoDB connection error:", err));

app.use('/api', apiRoutes);

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(` Server running at http://localhost:${PORT}`);
});