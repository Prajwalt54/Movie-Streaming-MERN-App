const express = require('express');
const router = express.Router();
const User = require('../models/User');
const Movie = require('../models/Movie');


router.post('/login', async (req, res) => {
    const { username, password } = req.body;

    try {
       
        let existingUser = await User.findOne({ username });

        if (existingUser) {
            
            if (existingUser.password === password) {
                return res.json({ success: true, message: "Welcome back!", user: existingUser });
            } else {
                return res.status(401).json({ success: false, message: "Incorrect password!" });
            }
        }

        const newUser = new User({ username, password });
        await newUser.save();
        res.json({ success: true, message: "Account created!", user: newUser });

    } catch (error) {
        console.error("Login Error:", error);
        res.status(500).json({ success: false, message: "Server error" });
    }
});


router.get('/movies', async (req, res) => {
    try {
        const movies = await Movie.find();
        res.json(movies);
    } catch (error) {
        res.status(500).json({ message: "Error fetching movies" });
    }
});


router.get('/movies/:id', async (req, res) => {
    try {
        const movie = await Movie.findById(req.params.id);
        if (!movie) return res.status(404).json({ message: "Movie not found" });
        res.json(movie);
    } catch (error) {
        res.status(500).json({ message: "Invalid Movie ID" });
    }
});

module.exports = router;