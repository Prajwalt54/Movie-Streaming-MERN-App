import axios from 'axios';

const API = axios.create({
  baseURL: import.meta.env.VITE_API_URL || 'http://localhost:5000'
});


export const getMovies = () => API.get('/api/movies');
export const getMovieById = (id) => API.get(`/api/movies/${id}`);
export const loginUser = (data) => API.post('/api/login', data);