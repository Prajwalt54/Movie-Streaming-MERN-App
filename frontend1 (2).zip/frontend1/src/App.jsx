import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

// Import our single Component that shows on every page
import Navbar from './components/Navbar';

// Import our three main Pages
import Home from './pages/Home';
import Login from './pages/Login';
import MovieDetails from './pages/MovieDetails';

function App() {
  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/login" element={<Login />} />
        <Route path="/movie/:id" element={<MovieDetails />} />
      </Routes>
    </Router>
  );
}

export default App;