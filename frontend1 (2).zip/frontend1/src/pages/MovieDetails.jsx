import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { getMovieById } from '../api/api';
import './MovieDetails.css';

const MovieDetails = () => {
  const { id } = useParams(); // Gets the ID from the URL
  const [movie, setMovie] = useState(null);
  const navigate = useNavigate();

  useEffect(() => {
    getMovieById(id)
      .then(res => setMovie(res.data))
      .catch(err => console.error("Error fetching single movie:", err));
  }, [id]);

  // Show a loading screen while waiting for the backend
  if (!movie) return <div className="loading">Loading movie details...</div>;

  return (
    <div className="details-container">
      <button className="back-btn" onClick={() => navigate(-1)}>← Back</button>

      <div className="details-content">
        <img
          src={movie.image || "https://via.placeholder.com/300x450?text=No+Poster"}
          alt={movie.title}
          className="details-poster"
          onError={(e) => {
            e.target.src = "https://via.placeholder.com/300x450?text=Image+Not+Found";
          }}
        />

        <div className="details-info">
          <h1>{movie.title}</h1>
          <span className="genre-tag">{movie.genre}</span>
          <p className="description">{movie.description}</p>

          {movie.videoUrl && (
            <a href={movie.videoUrl} target="_blank" rel="noreferrer">
              <button className="watch-btn">▶ Watch Now</button>
            </a>
          )}
        </div>
      </div>
    </div>
  );
};

export default MovieDetails;