import React, { useState, useEffect } from 'react';
import { getMovies } from '../api/api';
import { GenreBar } from '../components/GenreBar';
import { MovieSection } from '../components/MovieSection';
import './Home.css';

const Home = () => {
  const [movies, setMovies] = useState([]);
  const [filteredMovies, setFilteredMovies] = useState([]);
  const [activeGenre, setActiveGenre] = useState('All');

  const genres = ["All", "Action", "Comedy", "Horror", "Sci-Fi", "Drama"];

 
  useEffect(() => {
    getMovies()
      .then(res => {
        setMovies(res.data);
        setFilteredMovies(res.data);
      })
      .catch(err => console.error("Error fetching movies:", err));
  }, []);

  // Our safe, case-insensitive filter logic
  const handleGenre = (g) => {
    setActiveGenre(g);

    if (g === 'All') {
      setFilteredMovies(movies);
    } else {
      setFilteredMovies(
        movies.filter(m =>
          m.genre?.toLowerCase().trim() === g.toLowerCase()
        )
      );
    }
  };

  return (
    <div className="home-container">
      <GenreBar
        genres={genres}
        activeGenre={activeGenre}
        onGenreClick={handleGenre}
      />

      {/* Only show 'Popular' row if 'All' is selected */}
      {activeGenre === 'All' && (
        <MovieSection
          title="Popular Shows"
          movies={movies.filter(m => m.category === 'Popular')}
        />
      )}

      {/* Show filtered list */}
      <MovieSection
        title={activeGenre === 'All' ? "Latest Releases" : `${activeGenre} Movies`}
        movies={filteredMovies}
      />
    </div>
  );
};

export default Home;