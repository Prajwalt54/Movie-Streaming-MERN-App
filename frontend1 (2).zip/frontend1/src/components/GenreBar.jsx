import React from 'react';

export const GenreBar = ({ genres, activeGenre, onGenreClick }) => {
  return (
    <div className="genre-bar">
      {genres.map(g => (
        <button
          key={g}
          className={`genre-btn ${activeGenre === g ? 'active' : ''}`}
          onClick={() => onGenreClick(g)}
        >
          {g}
        </button>
      ))}
    </div>
  );
};