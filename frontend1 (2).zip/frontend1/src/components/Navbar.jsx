import React from 'react';
import { Link } from 'react-router-dom';
import './Navbar.css';

const Navbar = ({ onSearch }) => {
  return (
    <nav className="navbar">
      <Link to="/" className="logo">CINEPLAN</Link>
      
      {/* --- ADDED SEARCH BAR --- */}
      <div className="search-container">
        <input 
          type="text" 
          placeholder="Search movies..." 
          onChange={(e) => onSearch(e.target.value)}
          className="search-input"
        />
      </div>

      <div className="nav-links">
        <Link to="/" className="nav-item">Home</Link>
        <Link to="/login"><button className="login-btn">Login</button></Link>
      </div>
    </nav>
  );
};

export default Navbar;