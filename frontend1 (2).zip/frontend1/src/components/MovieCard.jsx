import React from 'react';
import { useNavigate } from 'react-router-dom';
import './MovieCard.css';

const MovieCard = ({ movie }) => {
  const navigate = useNavigate();

  return (
    // Navigate uses the MongoDB _id to go to the details page
    <div className="movie-card" onClick={() => navigate(`/movie/${movie._id}`)}>
      <img
        src={movie.image || "https://via.placeholder.com/300x450?text=No+Poster"}
        alt={movie.title}
        onError={(e) => {
          e.target.src = "https://via.placeholder.com/300x450?text=Image+Not+Found";
        }}
      />
      <div className="movie-info">
        <h3>{movie.title}</h3>
        <p>{movie.genre}</p>
      </div>
    </div>
  );
};

export default MovieCard;