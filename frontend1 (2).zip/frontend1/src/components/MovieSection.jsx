import React from 'react';
import MovieCard from './MovieCard';

export const MovieSection = ({ title, movies }) => {
  // If there are no movies in this category, don't render the section at all
  if (movies.length === 0) return null;

  return (
    <div className="movie-section">
      <h2 className="section-title">{title}</h2>
      <div className="movie-grid">
        {movies.map(movie => (
          // We pass the individual movie data down as a 'prop' to the card
          <MovieCard key={movie._id} movie={movie} />
        ))}
      </div>
    </div>
  );
};